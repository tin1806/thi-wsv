/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.impl.CountryDAOImpl;
import entity.Countries;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Admin
 */
@WebService(serviceName = "CustomerService")
public class CustomerService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName = "getCountries")
    public List<Countries> getCountries() {
        return new CountryDAOImpl().getCountries();
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getCountryById")
    public Countries getCountryById(@WebParam(name = "id") Integer id) {
        //TODO write your implementation code here:
        return new CountryDAOImpl().getCountryById(id);
    }
    
    @WebMethod(operationName = "insertCountry")
    public boolean insertCountry(@WebParam(name = "country") Countries country) {
        //TODO write your implementation code here:
        return new CountryDAOImpl().insertCountry(country);
    }
    
    @WebMethod(operationName = "updateCountry")
    public boolean updateCountry(@WebParam(name = "country") Countries country) {
        //TODO write your implementation code here:
        return new CountryDAOImpl().updateCountry(country);
    }
    
    @WebMethod(operationName = "deleteCountry")
    public boolean deleteCountry(@WebParam(name = "id") Integer id) {
        //TODO write your implementation code here:
        return new CountryDAOImpl().deleteCountry(id);
    }
    
    @WebMethod(operationName = "getCountriesByContinental")
    public List<Countries> getCountriesByContinental(@WebParam(name = "continental") String continental) {
        //TODO write your implementation code here:
        return new CountryDAOImpl().getCountriesByContinental(continental);
    }
    
    
}
