/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Countries;
import java.util.List;

/**
 *
 * @author Admin
 */
public interface CountryDAO {
    public List<Countries> getCountries();
    public Countries getCountryById(Integer cId);
    public boolean insertCountry(Countries c);
    public boolean updateCountry(Countries c);
    public boolean deleteCountry(Integer cId);
    public List<Countries> getCountriesByContinental(String continental);
}

