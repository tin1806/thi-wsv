/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlet;

import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.WebServiceRef;
import service.Countries;
import service.CustomerService_Service;

/**
 *
 * @author Admin
 */
@WebServlet(name = "AddCountry", urlPatterns = {"/AddCountry"})
public class AddCountry extends HttpServlet {

    @WebServiceRef(wsdlLocation = "WEB-INF/wsdl/localhost_8080/Review_Webservice/CustomerService.wsdl")
    private CustomerService_Service service;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            response.setContentType("text/html;charset=UTF-8");
            request.setCharacterEncoding("UTF-8");

            String name = request.getParameter("countryName");
            String continental = request.getParameter("continental");
            String date = request.getParameter("foundationDate");
            String area = request.getParameter("area");
            String population = request.getParameter("population");
            String language = request.getParameter("language");

            SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd");
            Date foundation = s.parse(date);

            Double are = Double.parseDouble(area);
            Double popula = Double.parseDouble(population);

            Countries c = new Countries();
            c.setArea(are);
            c.setContinental(continental);
            c.setCountryName(name);
            GregorianCalendar gre = new GregorianCalendar();
            gre.setTime(foundation);
            XMLGregorianCalendar xmlGre = new XMLGregorianCalendarImpl(gre);

            c.setFoundationDate(xmlGre);
            c.setLanguage(language);
            c.setPopulation(popula);

            boolean bl = insertCountry(c);
            if (bl) {
                request.setAttribute("success", "Insert successfully!");
                List<Countries> countries = getCountries();

                List<entity.Countries> listCountry = new ArrayList<>();
                for (Countries cc : countries) {
                    entity.Countries c1 = new entity.Countries();
                    c1.setCountryId(cc.getCountryId());
                    c1.setCountryName(cc.getCountryName());
                    c1.setArea(cc.getArea());
                    c1.setContinental(cc.getContinental());
                    c1.setFoundationDate(cc.getFoundationDate().toGregorianCalendar().getTime());
                    c1.setLanguage(cc.getLanguage());
                    c1.setPopulation(cc.getPopulation());
                    listCountry.add(c1);
                }

                request.setAttribute("list", listCountry);
                request.getRequestDispatcher("listCountries.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Insert failed!");
                request.getRequestDispatcher("insertCountry.jsp").forward(request, response);
            }
        } catch (ParseException ex) {
            Logger.getLogger(AddCountry.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private boolean insertCountry(service.Countries country) {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        service.CustomerService port = service.getCustomerServicePort();
        return port.insertCountry(country);
    }

    private java.util.List<service.Countries> getCountries() {
        // Note that the injected javax.xml.ws.Service reference as well as port objects are not thread safe.
        // If the calling of port operations may lead to race condition some synchronization is required.
        service.CustomerService port = service.getCustomerServicePort();
        return port.getCountries();
    }

}
