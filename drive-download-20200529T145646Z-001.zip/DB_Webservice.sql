create database DBExam
go
use DBExam
go
create table Countries(
	CountryId int identity primary key,
	CountryName nvarchar(200),
	Continental nvarchar(200),
	FoundationDate datetime,
	Area float,
	Population float,
	Language nvarchar(100))